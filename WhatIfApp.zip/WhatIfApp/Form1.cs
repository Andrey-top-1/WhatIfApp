﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
using System.Runtime.InteropServices;

namespace WhatIfApp
{
    public partial class Form1 : Form
    {
        [DllImport("shell32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr ExtractIcon(IntPtr hInst, string lpszExeFileName, int nIconIndex);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool DestroyIcon(IntPtr handle);

        // Цветовая схема
        private readonly Color DarkBackground = Color.FromArgb(24, 24, 32);
        private readonly Color PanelColor = Color.FromArgb(36, 36, 48);
        private readonly Color AccentColor = Color.FromArgb(0, 162, 250);
        private readonly Color TextColor = Color.White;
        private readonly Color ErrorColor = Color.FromArgb(255, 100, 100);

        // Элементы управления
        private TextBox txtScenario;
        private Button btnGenerate;
        private Button btnToggleParams;
        private Panel pnlParameters;
        private TabControl tabResults;
        private TextBox txtAnalysis;
        private PictureBox picMap;
        private ListBox lstSources;
        private Label lblStatus;
        private ProgressBar progressBar;
        private Button btnNewWindow;

        // Параметры
        private NumericUpDown numYear;
        private ComboBox cmbRegion;
        private TrackBar trackDetail;
        private NumericUpDown numWidth;
        private NumericUpDown numHeight;

        // API клиент
        private static readonly HttpClient httpClient = new HttpClient();
        private const string ExaApiKey = "77ebd763-9cb8-486a-81d3-27bd66a8415e";
        private const string PollinationsUrl = "https://image.pollinations.ai/prompt/";
        private const string OpenRouterApiKey = "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";

        public Form1()
        {
            InitializeComponent();
            InitializeUI();
            this.Text = "Historical WhatIf Analyzer [Версия: " + Guid.NewGuid().ToString().Substring(0, 5) + "]";
            this.MinimumSize = new Size(1200, 750);
            this.DoubleBuffered = true;
            this.Icon = GetApplicationIcon();
        }

        private Icon GetApplicationIcon()
        {
            try
            {
                IntPtr iconHandle = ExtractIcon(IntPtr.Zero, "shell32.dll", 15);
                if (iconHandle != IntPtr.Zero)
                {
                    var icon = Icon.FromHandle(iconHandle).Clone() as Icon;
                    DestroyIcon(iconHandle);
                    return icon;
                }
            }
            catch
            {
                return SystemIcons.Application;
            }
            return SystemIcons.Application;
        }

        private void InitializeUI()
        {
            this.BackColor = DarkBackground;
            this.ForeColor = TextColor;
            this.Font = new Font("Segoe UI", 9);
            this.Padding = new Padding(10);

            // Главный контейнер
            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 3,
                BackColor = DarkBackground,
                ColumnStyles =
                {
                    new ColumnStyle(SizeType.Percent, 70F),
                    new ColumnStyle(SizeType.Percent, 30F)
                },
                RowStyles =
                {
                    new RowStyle(SizeType.Absolute, 100),
                    new RowStyle(SizeType.Percent, 100),
                    new RowStyle(SizeType.Absolute, 40)
                }
            };

            // Заголовок
            var lblTitle = new Label
            {
                Text = "АНАЛИЗ АЛЬТЕРНАТИВНОЙ ИСТОРИИ",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = AccentColor
            };
            mainLayout.Controls.Add(lblTitle, 0, 0);
            mainLayout.SetColumnSpan(lblTitle, 2);

            // Левая панель
            var leftPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.Transparent
            };

            // Правая панель
            var rightPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = PanelColor,
                Padding = new Padding(15)
            };

            // Панель ввода
            var inputPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 140,
                BackColor = PanelColor,
                Padding = new Padding(20)
            };

            var lblScenario = new Label
            {
                Text = "Исторический сценарий:",
                Location = new Point(0, 5),
                AutoSize = true,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };

            txtScenario = new TextBox
            {
                Location = new Point(0, 30),
                Size = new Size(600, 30),
                Anchor = AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(50, 50, 60),
                ForeColor = TextColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            btnGenerate = new Button
            {
                Text = "Сгенерировать анализ (AI)",
                Location = new Point(0, 70),
                Size = new Size(220, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = AccentColor,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnGenerate.FlatAppearance.BorderColor = AccentColor;

            btnNewWindow = new Button
            {
                Text = "Новое окно",
                Location = new Point(230, 70),
                Size = new Size(150, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(70, 70, 90),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9),
                Cursor = Cursors.Hand,
                Image = CreateIconImage('\uE768', Color.White),
                ImageAlign = ContentAlignment.MiddleLeft,
                TextImageRelation = TextImageRelation.ImageBeforeText
            };
            btnNewWindow.FlatAppearance.BorderColor = AccentColor;

            // Обработчик для новой кнопки
            btnNewWindow.Click += (s, e) => CreateNewIndependentWindow();

            // Эффекты при наведении
            btnNewWindow.MouseEnter += (s, e) => btnNewWindow.BackColor = Color.FromArgb(90, 90, 110);
            btnNewWindow.MouseLeave += (s, e) => btnNewWindow.BackColor = Color.FromArgb(70, 70, 90);

            inputPanel.Controls.AddRange(new Control[] {
                lblScenario,
                txtScenario,
                btnGenerate,
                btnNewWindow
            });

            // Вкладки результатов
            tabResults = new TabControl
            {
                Dock = DockStyle.Fill,
                Appearance = TabAppearance.FlatButtons,
                ItemSize = new Size(150, 30),
                SizeMode = TabSizeMode.Fixed,
                BackColor = PanelColor
            };
            InitializeResultTabs();

            leftPanel.Controls.Add(tabResults);
            leftPanel.Controls.Add(inputPanel);

            // Правая панель параметров
            InitializeParametersPanel(rightPanel);

            // Статус бар
            var pnlStatus = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = PanelColor,
                Padding = new Padding(10)
            };

            progressBar = new ProgressBar
            {
                Location = new Point(0, 5),
                Size = new Size(200, 20),
                Style = ProgressBarStyle.Continuous,
                ForeColor = AccentColor
            };

            lblStatus = new Label
            {
                Location = new Point(210, 5),
                AutoSize = true,
                Text = "Готов к работе",
                TextAlign = ContentAlignment.MiddleLeft
            };

            pnlStatus.Controls.AddRange(new Control[] { progressBar, lblStatus });

            // Сборка главного макета
            mainLayout.Controls.Add(leftPanel, 0, 1);
            mainLayout.Controls.Add(rightPanel, 1, 1);
            mainLayout.Controls.Add(pnlStatus, 0, 2);
            mainLayout.SetColumnSpan(pnlStatus, 2);

            this.Controls.Add(mainLayout);

            // Обработчики событий
            btnGenerate.Click += async (s, e) => await GenerateAnalysis();
            txtScenario.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) btnGenerate.PerformClick(); };

            btnGenerate.MouseEnter += (s, e) => btnGenerate.BackColor = Color.FromArgb(0, 172, 255);
            btnGenerate.MouseLeave += (s, e) => btnGenerate.BackColor = AccentColor;
        }

        private void CreateNewIndependentWindow()
        {
            var newWindow = new Form1();

            // Устанавливаем позицию нового окна смещенной от текущего
            newWindow.StartPosition = FormStartPosition.Manual;
            newWindow.Location = new Point(
                this.Location.X + this.Width + 10,
                this.Location.Y
            );

            // Убедимся, что окно остается в пределах экрана
            Rectangle screen = Screen.FromControl(this).WorkingArea;
            if (newWindow.Left + newWindow.Width > screen.Right)
            {
                newWindow.Left = screen.Right - newWindow.Width;
            }
            if (newWindow.Top + newWindow.Height > screen.Bottom)
            {
                newWindow.Top = screen.Bottom - newWindow.Height;
            }

            newWindow.Show();
        }


        private void InitializeParametersPanel(Panel container)
        {
            container.Controls.Clear();

            var title = new Label
            {
                Text = "Параметры анализа",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = AccentColor,
                Height = 40
            };

            var contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(10)
            };

            // Год
            var lblYear = new Label
            {
                Text = "Год:",
                Location = new Point(0, 50),
                AutoSize = true
            };

            numYear = new NumericUpDown
            {
                Location = new Point(50, 50),
                Size = new Size(100, 55),
                Minimum = 1000,
                Maximum = 2100,
                Value = 1861,
                BackColor = Color.FromArgb(50, 50, 60),
                ForeColor = TextColor
            };

            // Регион
            var lblRegion = new Label
            {
                Text = "Регион:",
                Location = new Point(0, 105),
                AutoSize = true
            };

            cmbRegion = new ComboBox
            {
                Location = new Point(50, 100),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Items = { "Европа", "Азия", "Америка", "Африка", "Ближний Восток", "Россия", "Глобальный" },
                BackColor = Color.FromArgb(50, 50, 60),
                ForeColor = TextColor
            };
            cmbRegion.SelectedIndex = 0;

            // Детализация
            var lblDetail = new Label
            {
                Text = "Детализация:",
                Location = new Point(0, 145),
                AutoSize = true
            };

            trackDetail = new TrackBar
            {
                Location = new Point(80, 140),
                Size = new Size(150, 45),
                Minimum = 1,
                Maximum = 5,
                Value = 3,
                BackColor = Color.FromArgb(50, 50, 60)
            };

            // Размеры изображения
            var lblWidth = new Label
            {
                Text = "Ширина:",
                Location = new Point(0, 200),
                AutoSize = true
            };

            numWidth = new NumericUpDown
            {
                Location = new Point(60, 200),
                Size = new Size(70, 25),
                Minimum = 256,
                Maximum = 4096,
                Value = 1024,
                BackColor = Color.FromArgb(50, 50, 60),
                ForeColor = TextColor
            };

            var lblHeight = new Label
            {
                Text = "Высота:",
                Location = new Point(140, 200),
                AutoSize = true
            };

            numHeight = new NumericUpDown
            {
                Location = new Point(190, 200),
                Size = new Size(70, 25),
                Minimum = 256,
                Maximum = 4096,
                Value = 768,
                BackColor = Color.FromArgb(50, 50, 60),
                ForeColor = TextColor
            };





            contentPanel.Controls.AddRange(new Control[] {
                lblYear, numYear, lblRegion, cmbRegion,
                lblDetail, trackDetail, lblWidth, numWidth,
                lblHeight, numHeight,
            });

            container.Controls.Add(title);
            container.Controls.Add(contentPanel);
        }

        private void InitializeResultTabs()
        {
            // Вкладка анализа
            var tabAnalysis = new TabPage("Исторический анализ")
            {
                BackColor = PanelColor,
                Padding = new Padding(10)
            };

            txtAnalysis = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(40, 40, 50),
                ForeColor = TextColor,
                BorderStyle = BorderStyle.None,
                ReadOnly = true
            };
            tabAnalysis.Controls.Add(txtAnalysis);

            // Вкладка карты
            var tabMap = new TabPage("Изменения на карте")
            {
                BackColor = PanelColor,
                Padding = new Padding(10)
            };

            picMap = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.FromArgb(40, 40, 50),
                BorderStyle = BorderStyle.FixedSingle
            };
            tabMap.Controls.Add(picMap);

            // Вкладка источников
            var tabSources = new TabPage("Документальные источники")
            {
                BackColor = PanelColor,
                Padding = new Padding(10)
            };

            lstSources = new ListBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10),
                BackColor = Color.FromArgb(40, 40, 50),
                ForeColor = TextColor,
                BorderStyle = BorderStyle.None
            };
            tabSources.Controls.Add(lstSources);

            tabResults.TabPages.AddRange(new TabPage[] { tabAnalysis, tabMap, tabSources });
        }

        private async Task GenerateAnalysis()
        {
            if (string.IsNullOrWhiteSpace(txtScenario.Text))
            {
                ShowStatus("Введите исторический сценарий", true);
                return;
            }

            try
            {
                ShowStatus("Анализируем сценарий...");
                progressBar.Style = ProgressBarStyle.Marquee;
                btnGenerate.Enabled = false;

                // Очищаем предыдущие результаты
                txtAnalysis.Text = string.Empty;
                lstSources.Items.Clear();

                // Генерация анализа через API
                string analysis;
                if (true)
                {
                    analysis = await GenerateHistoricalAnalysisWithAI(txtScenario.Text);

                    // Фильтрация текста через AI
                    if (true)
                    {
                        var filtered = await FilterAndExtractSourcesWithAI(analysis);
                        txtAnalysis.Text = filtered.MainText;
                        AddSourcesToList(filtered.References);
                    }
                    else
                    {
                        // Автоматическое разделение без AI
                        var split = ExtractSourcesManually(analysis);
                        txtAnalysis.Text = split.MainText;
                        AddSourcesToList(split.References);
                    }

                    // Генерация карты через Pollinations AI
                    await GenerateAIMapImage(analysis);
                }
                else
                {
                    analysis = GenerateHistoricalAnalysis(txtScenario.Text);
                    txtAnalysis.Text = analysis;
                    GenerateMapImage();
                }

                // Загрузка дополнительных источников
                await LoadHistoricalSources(txtScenario.Text);

                ShowStatus("Анализ завершен успешно");
                tabResults.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ShowStatus($"Ошибка: {ex.Message}", true);
                txtAnalysis.Text = $"Произошла ошибка при анализе:\n{ex.Message}\n\nStack Trace:\n{ex.StackTrace}";
            }
            finally
            {
                progressBar.Style = ProgressBarStyle.Continuous;
                progressBar.Value = 100;
                btnGenerate.Enabled = true;
            }
        }

        private void AddSourcesToList(string references)
        {
            if (string.IsNullOrWhiteSpace(references))
                return;

            foreach (var line in references.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    lstSources.Items.Add(line.Trim());
                }
            }
        }

        private (string MainText, string References) ExtractSourcesManually(string text)
        {
            var references = new StringBuilder();
            var mainText = new StringBuilder();
            bool inReferences = false;

            foreach (var line in text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None))
            {
                if (line.Contains("http://") || line.Contains("https://") ||
                    line.StartsWith("Источники:") || line.StartsWith("Ссылки:") ||
                    line.StartsWith("References:") || line.StartsWith("Sources:"))
                {
                    inReferences = true;
                }

                if (inReferences)
                {
                    references.AppendLine(line);
                }
                else
                {
                    mainText.AppendLine(line);
                }
            }

            return (mainText.ToString(), references.ToString());
        }

        private async Task<(string MainText, string References)> FilterAndExtractSourcesWithAI(string text)
        {
            try
            {
                ShowStatus("Фильтрация текста через AI...");

                var requestData = new
                {
                    model = "google/gemini-2.0-flash-exp:free",
                    messages = new[]
                    {
                        new
                        {
                            role = "user",
                            content = new[]
                            {
                                new
                                {
                                    type = "text",
                                    text = $"Раздели следующий текст на две части: основной текст и ссылки на источники. " +
                                           $"Основной текст должен быть кратким и содержательным (не более 500 слов). " +
                                           $"Ссылки на источники должны быть перечислены в конце. " +
                                           $"Ссылки на источники должны быть крассиво офрмленны" +
                                           $"Ответ предоставь в формате JSON с полями 'main_text' и 'references'. " +
                                           $"Вот текст:\n\n{text}"
                                }
                            }
                        }
                    }
                };

                var json = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (var request = new HttpRequestMessage(HttpMethod.Post, "https://openrouter.ai/api/v1/chat/completions"))
                {
                    request.Headers.Add("Authorization", $"Bearer {OpenRouterApiKey}");
                    request.Headers.Add("HTTP-Referer", "https://whatifapp.com");
                    request.Headers.Add("X-Title", "WhatIf App");
                    request.Content = content;

                    var response = await httpClient.SendAsync(request);
                    response.EnsureSuccessStatusCode();

                    var responseJson = await response.Content.ReadAsStringAsync();
                    dynamic result = JsonConvert.DeserializeObject(responseJson);

                    try
                    {
                        var contentJson = JsonConvert.DeserializeObject<dynamic>(result.choices[0].message.content.ToString());
                        return (contentJson.main_text.ToString(), contentJson.references.ToString());
                    }
                    catch
                    {
                        return (result.choices[0].message.content.ToString(), string.Empty);
                    }
                }
            }
            catch (Exception ex)
            {
                ShowStatus($"Ошибка фильтрации: {ex.Message}", true);
                return ExtractSourcesManually(text);
            }
        }

        private async Task<string> GenerateHistoricalAnalysisWithAI(string scenario)
        {
            try
            {
                ShowStatus("Запрос к AI...");

                var requestData = new
                {
                    query = $"Подробный анализ альтернативного исторического сценария. Важно обязательно на Русском языке: {scenario} в {numYear.Value} году в регионе {cmbRegion.SelectedItem}. " +
                            $"Детализация уровня {trackDetail.Value}. Включите политические, экономические и социальные последствия.",
                    type = "neural",
                    contents = new { text = true },
                    highlights = new { text = true }
                };

                var json = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                httpClient.DefaultRequestHeaders.Add("x-api-key", ExaApiKey);
                var response = await httpClient.PostAsync("https://api.exa.ai/search", content);
                response.EnsureSuccessStatusCode();

                var responseJson = await response.Content.ReadAsStringAsync();
                dynamic result = JsonConvert.DeserializeObject(responseJson);

                StringBuilder analysis = new StringBuilder();
                analysis.AppendLine($"АЛЬТЕРНАТИВНЫЙ ИСТОРИЧЕСКИЙ АНАЛИЗ");
                analysis.AppendLine($"Сценарий: {scenario}");
                analysis.AppendLine($"Год: {numYear.Value}, Регион: {cmbRegion.SelectedItem}");
                analysis.AppendLine("----------------------------------------\n");

                if (result.results != null)
                {
                    foreach (var item in result.results)
                    {
                        analysis.AppendLine(item.text?.ToString() ?? "");
                    }
                }

                return analysis.ToString();
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при запросе к AI: {ex.Message}");
            }
        }

        private async Task GenerateAIMapImage(string analysisText)
        {
            try
            {
                ShowStatus("Генерация карты...");

                string mapPrompt = $"Historical map of {cmbRegion.SelectedItem} in {numYear.Value} showing alternate history scenario: " +
                                  $"{txtScenario.Text}. " +
                                  $"Style: detailed antique map with borders, cities, and annotations. " +
                                  $"Resolution: {numWidth.Value}x{numHeight.Value}. " +
                                  $"Detail level: {trackDetail.Value}/5";

                string encodedPrompt = Uri.EscapeDataString(mapPrompt);
                string imageUrl = $"{PollinationsUrl}{encodedPrompt}?width={numWidth.Value}&height={numHeight.Value}";

                var response = await httpClient.GetAsync(imageUrl);
                response.EnsureSuccessStatusCode();

                using (var stream = await response.Content.ReadAsStreamAsync())
                {
                    picMap.Image = Image.FromStream(stream);
                }
            }
            catch (Exception ex)
            {
                GenerateMapImage();
                throw new Exception($"Не удалось сгенерировать карту через AI: {ex.Message}");
            }
        }

        private async Task LoadHistoricalSources(string scenario)
        {
            try
            {
                ShowStatus("Поиск источников...");

                var requestData = new
                {
                    query = $"Исторические источники и документы о {scenario} в {numYear.Value} году",
                    type = "news",
                    numResults = 10
                };

                var json = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                httpClient.DefaultRequestHeaders.Add("x-api-key", ExaApiKey);
                var response = await httpClient.PostAsync("https://api.exa.ai/search", content);
                response.EnsureSuccessStatusCode();

                var responseJson = await response.Content.ReadAsStringAsync();
                dynamic result = JsonConvert.DeserializeObject(responseJson);

                var sources = new List<string>();
                if (result.results != null)
                {
                    foreach (var item in result.results)
                    {
                        string url = item.url?.ToString() ?? "";
                        if (IsRussianSource(url))
                        {
                            sources.Add($"{item.title} - {url}");
                        }
                    }
                }

                if (sources.Count > 0)
                {
                    var processedSources = await ProcessSourcesWithGemini(sources);
                    UpdateSourcesList(processedSources);
                }
            }
            catch (Exception ex)
            {
                lstSources.Items.Add($"Не удалось загрузить источники: {ex.Message}");
            }
        }

        private bool IsRussianSource(string url)
        {
            if (string.IsNullOrEmpty(url)) return false;

            var forbiddenDomains = new[]
            {
                "wikipedia.org",
                "fandom.com",
                ".uk",
                ".com",
                ".org",
                ".net",
                ".io"
            };

            // Разрешаем только российские домены и русскоязычные ресурсы
            return Regex.IsMatch(url, @"\.ru($|/)|rf|рус|россия|русский", RegexOptions.IgnoreCase) &&
                   !forbiddenDomains.Any(d => url.Contains(d));
        }

        private async Task<List<string>> ProcessSourcesWithGemini(List<string> sources)
        {
            try
            {
                ShowStatus("Обработка источников через AI...");

                var sourcesText = string.Join("\n", sources);
                var requestData = new
                {
                    model = "google/gemini-2.0-flash-exp:free",
                    messages = new[]
                    {
                        new
                        {
                            role = "user",
                            content = new[]
                            {
                                new
                                {
                                    type = "text",
                                    text = $"Улучши читаемость и структуру следующих исторических источников. " +
                                           $"Сделай заголовки более информативными, добавь краткое описание (1-2 предложения) для каждого источника. " +
                                           $"Сохрани оригинальные ссылки. Формат:\n" +
                                           $"• [Заголовок] ([Год])\n" +
                                           $"  [Описание]\n" +
                                           $"  Ссылка: [URL]\n\n" +
                                           $"Источники:\n{sourcesText}"
                                }
                            }
                        }
                    }
                };

                var json = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (var request = new HttpRequestMessage(HttpMethod.Post, "https://openrouter.ai/api/v1/chat/completions"))
                {
                    request.Headers.Add("Authorization", $"Bearer {OpenRouterApiKey}");
                    request.Headers.Add("HTTP-Referer", "https://whatifapp.com");
                    request.Headers.Add("X-Title", "WhatIf App");
                    request.Content = content;

                    var response = await httpClient.SendAsync(request);
                    response.EnsureSuccessStatusCode();

                    var responseJson = await response.Content.ReadAsStringAsync();
                    dynamic result = JsonConvert.DeserializeObject(responseJson);

                    return ProcessAIResponse(result.choices[0].message.content.ToString());
                }
            }
            catch
            {
                return sources; // Возвращаем оригинальные источники при ошибке
            }
        }

        private List<string> ProcessAIResponse(string aiText)
        {
            var processedSources = new List<string>();
            var lines = aiText.Split(new[] { "\n• ", "\n", "• " }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var line in lines)
            {
                if (line.Contains("Ссылка:") && IsRussianSource(line))
                {
                    processedSources.Add(line.Trim().Replace("  ", "\t"));
                }
            }

            return processedSources.Count > 0 ? processedSources : new List<string> { "Источники не найдены" };
        }

        private void UpdateSourcesList(List<string> sources)
        {
            if (lstSources.InvokeRequired)
            {
                lstSources.Invoke((MethodInvoker)delegate
                {
                    lstSources.Items.Clear();
                    lstSources.Items.AddRange(sources.ToArray());
                });
            }
            else
            {
                lstSources.Items.Clear();
                lstSources.Items.AddRange(sources.ToArray());
            }
        }

        private string GenerateHistoricalAnalysis(string scenario)
        {
            return $"Анализ альтернативного сценария: {scenario}\n\n" +
                   $"Год: {numYear.Value}, Регион: {cmbRegion.SelectedItem}\n" +
                   "----------------------------------------\n\n" +
                   "1. Политические последствия:\n" +
                   $"   - Изменение баланса сил в {cmbRegion.SelectedItem}\n" +
                   "   - Возможные изменения в международных договорах\n" +
                   $"   - Влияние на правящие династии в {numYear.Value} году\n\n" +
                   "2. Экономические изменения:\n" +
                   $"   - Влияние на торговые маршруты в {cmbRegion.SelectedItem}\n" +
                   $"   - Изменение ВВП и экономического роста в {numYear.Value} году\n" +
                   "   - Последствия для сельского хозяйства и промышленности\n\n" +
                   "3. Социальные аспекты:\n" +
                   "   - Миграционные потоки\n" +
                   "   - Изменения в демографической структуре\n" +
                   $"   - Культурные последствия для {cmbRegion.SelectedItem}";
        }

        private void GenerateMapImage()
        {
            try
            {
                using (var bmp = new Bitmap((int)numWidth.Value, (int)numHeight.Value))
                using (var g = Graphics.FromImage(bmp))
                {
                    g.Clear(Color.FromArgb(40, 40, 80));

                    using (var regionBrush = new SolidBrush(Color.FromArgb(60, 60, 120)))
                    {
                        if (cmbRegion.SelectedItem.ToString() == "Европа")
                        {
                            g.FillPolygon(regionBrush, new Point[] { new Point(400, 150), new Point(600, 100), new Point(700, 200), new Point(650, 400), new Point(400, 500) });
                        }
                        else if (cmbRegion.SelectedItem.ToString() == "Азия")
                        {
                            g.FillPolygon(regionBrush, new Point[] { new Point(700, 100), new Point(850, 150), new Point(800, 400), new Point(650, 500) });
                        }
                    }

                    using (var font = new Font("Arial", 24, FontStyle.Bold))
                    using (var smallFont = new Font("Arial", 12))
                    {
                        g.DrawString($"Альтернативная карта {cmbRegion.SelectedItem}", font, Brushes.White, new PointF(bmp.Width / 4, 50));
                        g.DrawString($"Год: {numYear.Value}", smallFont, Brushes.White, new PointF(50, bmp.Height - 50));
                        g.DrawString($"Сценарий: {txtScenario.Text}", smallFont, Brushes.White, new PointF(bmp.Width / 3, bmp.Height - 30));
                    }

                    picMap.Image = (Image)bmp.Clone();
                }
            }
            catch (Exception ex)
            {
                ShowStatus($"Ошибка при генерации карты: {ex.Message}", true);
            }
        }

        private void ToggleParameters()
        {
            if (pnlParameters.Height == 0)
            {
                pnlParameters.Height = 210;
                btnToggleParams.Text = "▲ Скрыть параметры";
            }
            else
            {
                pnlParameters.Height = 0;
                btnToggleParams.Text = "▼ Дополнительные параметры";
            }
        }

        private Bitmap CreateIconImage(char iconChar, Color color)
        {
            const int size = 16;
            Bitmap bmp = new Bitmap(size, size);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.Transparent);
                using (Font iconFont = new Font("Segoe MDL2 Assets", 10))
                using (SolidBrush brush = new SolidBrush(color))
                {
                    g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                    g.DrawString(iconChar.ToString(), iconFont, brush, new PointF(-2, 1));
                }
            }
            return bmp;
        }

        private void ShowStatus(string message, bool isError = false)
        {
            lblStatus.ForeColor = isError ? ErrorColor : TextColor;
            lblStatus.Text = message;

            if (isError)
            {
                var timer = new Timer { Interval = 5000 };
                timer.Tick += (s, e) => {
                    lblStatus.Text = "Готов к работе";
                    lblStatus.ForeColor = TextColor;
                    timer.Stop();
                    timer.Dispose();
                };
                timer.Start();
            }
        }
    }
}
